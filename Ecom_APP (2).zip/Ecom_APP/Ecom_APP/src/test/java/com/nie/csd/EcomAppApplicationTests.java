package com.nie.csd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
