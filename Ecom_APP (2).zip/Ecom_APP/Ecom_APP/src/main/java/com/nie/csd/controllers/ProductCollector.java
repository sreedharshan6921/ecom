import org.springframework.stereotype.Controller;

@Controller
public class ProductCollector {
 @getMapping("/products")
 public String getProducts() {
     return "products";
 }

 @getMapping("/addProduct")
 public String addProduct() {
     return "addProduct";
 }              

}       

